---
# Display name
name: Girish Varma
avatar_image: "profile_pic.jpg"
# Username (this should match the folder name)
authors:
- girishvarma
# resume download button
#btn:
#- url : "https://sourcethemes.com/academic/docs/install/"
#  label : "Download Resume"

# Is this the primary user of the site?
superuser: true

# Role/position
role: Assistant Professor

# Organizations/Affiliations
organizations:
- name: Center for Security, Theory and Algorithmic Research
  url: "https://cstar.iiit.ac.in"
- name: Machine Learning Lab
  url: "https://mll.iiit.ac.in"
- name: Kohli Center for Intelligent Systems
  url: "https://kcis.iiit.ac.in"
- name: IIIT Hyderabad
  url: "https://iiit.ac.in"

# Short bio (displayed in user profile at end of posts)
bio: broadly interested in theoretical and applied computer science problems.

# Should the user's education and interests be displayed?
display_education: true

interests:
- Theory CS
- ML
- Interdisciplinary


social:
- icon: envelope
  icon_pack: fas
  link: '#contact'  # For a direct email link, use "mailto:test@example.org".

- icon: google-scholar
  icon_pack: ai
  link: https://scholar.google.co.in/citations?user=YLlRCu4AAAAJ&hl=en

email: "girish.varma@iiit.ac.in"
  
# Organizational groups that you belong to (for People widget)
#   Set this to `[]` or comment out if you are not using People widget.  
user_groups:
- Faculty
- Visitors
---

